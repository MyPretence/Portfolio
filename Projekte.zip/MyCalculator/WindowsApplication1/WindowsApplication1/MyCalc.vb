﻿Public Class MyCalc
    ' Variablen deklarieren
    Private dblZahl1 As Double = 0
    Private dblZahl2 As Double = 0
    Private dblErgebnis As Double = 0
    Private txtInput As Double = 0
    ' Plus
    Private Sub cmdPlus_Click(sender As Object, e As EventArgs) Handles cmdPlus.Click
        Dim dblZahl1 As Double
        Dim dblZahl As Double
        Label2.Text = Me.txt1.Text + Me.txt2.Text

        'Fehleranzeige bei Buchstabeneingabe
        If IsNumeric(txt1.Text & txt1.Text) = False Then
            MessageBox.Show("Bitte nur Zahlen eintragen!")
            txt1.Focus()
            Exit Sub
        End If

        dblZahl = txt1.Text

        ' Variable mit dem Inhalt der Textboxen füllen
        dblZahl1 = Me.txt1.Text
        dblZahl2 = Me.txt2.Text

        ' Ergebnis berechnen und in Ausgabevariable abspeichern 
        dblErgebnis = dblZahl1 + dblZahl2

        ' Ergebnis ausgeben
        Label1.Text = Me.txt1.Text + "+" + Me.txt2.Text + "=" & dblErgebnis
        Label2.Text = dblErgebnis

    End Sub
    ' Sub
    Private Sub cmdSub_Click(sender As Object, e As EventArgs) Handles cmdSub.Click
        Dim dblZahl1 As Double
        Label2.Text = Me.txt1.Text + Me.txt2.Text

        If IsNumeric(txt1.Text & txt1.Text) = False Then
            MessageBox.Show("Bitte nur Zahlen eintragen!")
            txt1.Focus()
            Exit Sub
        End If

        dblZahl1 = Me.txt1.Text
        dblZahl2 = Me.txt2.Text

        ' Ergebnis berechnen und in Ausgabevariable abspeichern 
        dblErgebnis = dblZahl1 - dblZahl2

        ' Ergebnis ausgeben
        Label1.Text = Me.txt1.Text + "-" + Me.txt2.Text + "=" & dblErgebnis
        Label2.Text = dblErgebnis

    End Sub
    ' PlusMinus
    Private Sub cmdPlusSub_Click(sender As Object, e As EventArgs) Handles cmdPlusSub.Click
        Dim dblZahl1 As Double
        Label2.Text = Me.txt1.Text + Me.txt2.Text

        If IsNumeric(txt1.Text & txt1.Text) = False Then
            MessageBox.Show("Bitte nur Zahlen eintragen!")
            txt1.Focus()
            Exit Sub
        End If

        dblZahl1 = Me.txt1.Text

        ' Ergebnis berechnen und in Ausgabevariable abspeichern 
        dblErgebnis = (dblZahl1 * -1)

        ' Ergebnis ausgeben
        Label1.Text = Me.txt1.Text + "+-" + Me.txt2.Text + "=" & dblErgebnis
        Label2.Text = dblErgebnis

    End Sub
    ' Multiplizieren
    Private Sub cmdMulti_Click(sender As Object, e As EventArgs) Handles cmdMulti.Click
        Dim dblZahl1 As Double
        Label2.Text = Me.txt1.Text + Me.txt2.Text

        If IsNumeric(txt1.Text & txt1.Text) = False Then
            MessageBox.Show("Bitte nur Zahlen eintragen!")
            txt1.Focus()
            Exit Sub
        End If

        dblZahl1 = Me.txt1.Text
        dblZahl2 = Me.txt2.Text

        ' Ergebnis berechnen und in Ausgabevariable abspeichern 
        dblErgebnis = dblZahl1 * dblZahl2

        ' Ergebnis ausgeben
        Label1.Text = Me.txt1.Text + "*" + Me.txt2.Text + "=" & dblErgebnis
        Label2.Text = dblErgebnis

    End Sub
    ' Prozent
    Private Sub cmdPercent_Click(sender As Object, e As EventArgs) Handles cmdPercent.Click
        Dim dblZahl1 As Double
        Label2.Text = Me.txt1.Text + Me.txt2.Text

        If IsNumeric(txt1.Text & txt1.Text) = False Then
            MessageBox.Show("Bitte nur Zahlen eintragen!")
            txt1.Focus()
            Exit Sub
        End If


        dblZahl1 = Me.txt1.Text
        dblZahl2 = Me.txt2.Text

        ' Ergebnis berechnen und in Ausgabevariable abspeichern 
        dblErgebnis = (dblZahl1 / 100) * dblZahl2

        ' Ergebnis ausgeben
        Label1.Text = Me.txt1.Text + "%" + Me.txt2.Text + "=" & dblErgebnis
        Label2.Text = dblErgebnis

    End Sub
    ' Geteilt
    Private Sub cmdSlash1_Click(sender As Object, e As EventArgs) Handles cmdSlash1.Click
        Dim dblZahl1 As Double
        Label2.Text = Me.txt1.Text + Me.txt2.Text

        If IsNumeric(txt1.Text & txt1.Text) = False Then
            MessageBox.Show("Bitte nur Zahlen eintragen!")
            txt1.Focus()
            Exit Sub
        End If

        dblZahl1 = Me.txt1.Text
        dblZahl2 = Me.txt2.Text

        ' Ergebnis berechnen und in Ausgabevariable abspeichern 
        dblErgebnis = dblZahl1 / dblZahl2

        ' Ergebnis ausgeben
        Label1.Text = Me.txt1.Text + "/" + Me.txt2.Text + "=" & dblErgebnis
        Label2.Text = dblErgebnis

    End Sub
    ' Hoch
    Private Sub cmdSquared_Click(sender As Object, e As EventArgs) Handles cmdSquared.Click
        Dim dblZahl1 As Double
        Label2.Text = Me.txt1.Text + Me.txt2.Text

        If IsNumeric(txt1.Text & txt1.Text) = False Then
            MessageBox.Show("Bitte nur Zahlen eintragen!")
            txt1.Focus()
            Exit Sub
        End If

        dblZahl1 = Me.txt1.Text
        dblZahl2 = Me.txt2.Text

        ' Ergebnis berechnen und in Ausgabevariable abspeichern 
        dblErgebnis = dblZahl1 ^ dblZahl2

        ' Ergebnis ausgeben
        Label2.Text = dblErgebnis
        Label1.Text = Me.txt1.Text + "^" + Me.txt2.Text + "=" & dblErgebnis
    End Sub
    ' Wurzel
    Private Sub cmdRoot_Click(sender As Object, e As EventArgs) Handles cmdRoot.Click
        Dim dblZahl1 As Double
        Label2.Text = Me.txt1.Text + Me.txt2.Text

        If IsNumeric(txt1.Text & txt1.Text) = False Then
            MessageBox.Show("Bitte nur Zahlen eintragen!")
            txt1.Focus()
            Exit Sub
        End If

        dblZahl1 = Me.txt1.Text

        ' Ergebnis berechnen und in Ausgabevariable abspeichern 
        dblErgebnis = (dblZahl1 ^ 0.5)

        ' Ergebnis ausgeben
        Label2.Text = dblErgebnis
        Label1.Text = Me.txt1.Text + "^ 0.5" + Me.txt2.Text + "=" & dblErgebnis

    End Sub
    'Reset
    Private Sub cmdReset_Click(sender As Object, e As EventArgs) Handles cmdReset.Click

        txt1.Text = ""
        txt2.Text = ""
        Label2.Text = "0"

    End Sub
    Private Sub cmdSlash2_Click(sender As Object, e As EventArgs) Handles cmdSlash2.Click
        Dim dblZahl1 As Double

        If IsNumeric(txt1.Text & txt1.Text) = False Then
            MessageBox.Show("Bitte nur Zahlen eintragen!")
            txt1.Focus()
            Exit Sub
        End If

        ' Variablen initialisieren, Wert aus Textbox in Variable abspeichern 
        dblZahl1 = txt1.Text
        dblZahl2 = txt2.Text

        ' Ergebnis berechnen und in Ausgabevariable abspeichern 
        dblErgebnis = dblZahl1 \ dblZahl2

        ' Ergebnis ausgeben 
        Label2.Text = dblErgebnis
        Label1.Text = Me.txt1.Text + "\" + Me.txt2.Text + "=" & dblErgebnis

    End Sub

End Class
