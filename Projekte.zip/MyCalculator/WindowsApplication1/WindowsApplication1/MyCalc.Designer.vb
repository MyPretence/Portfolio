﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MyCalc
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MyCalc))
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.txt2 = New System.Windows.Forms.TextBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.cmdSquared = New System.Windows.Forms.Button()
        Me.cmdSlash1 = New System.Windows.Forms.Button()
        Me.cmdPercent = New System.Windows.Forms.Button()
        Me.cmdSlash2 = New System.Windows.Forms.Button()
        Me.cmdRoot = New System.Windows.Forms.Button()
        Me.cmdPlus = New System.Windows.Forms.Button()
        Me.cmdReset = New System.Windows.Forms.Button()
        Me.cmdMulti = New System.Windows.Forms.Button()
        Me.cmdPlusSub = New System.Windows.Forms.Button()
        Me.cmdSub = New System.Windows.Forms.Button()
        Me.panel1 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BindingSource1 = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.panel1.SuspendLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txt1
        '
        Me.txt1.Location = New System.Drawing.Point(22, 33)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(285, 20)
        Me.txt1.TabIndex = 0
        '
        'txt2
        '
        Me.txt2.Location = New System.Drawing.Point(23, 69)
        Me.txt2.Name = "txt2"
        Me.txt2.Size = New System.Drawing.Size(285, 20)
        Me.txt2.TabIndex = 1
        '
        'PictureBox3
        '
        Me.PictureBox3.Location = New System.Drawing.Point(205, 159)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(30, 30)
        Me.PictureBox3.TabIndex = 7
        Me.PictureBox3.TabStop = False
        '
        'cmdSquared
        '
        Me.cmdSquared.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSquared.Location = New System.Drawing.Point(133, 157)
        Me.cmdSquared.Name = "cmdSquared"
        Me.cmdSquared.Size = New System.Drawing.Size(30, 30)
        Me.cmdSquared.TabIndex = 15
        Me.cmdSquared.Text = "x²"
        Me.cmdSquared.UseVisualStyleBackColor = True
        '
        'cmdSlash1
        '
        Me.cmdSlash1.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSlash1.Location = New System.Drawing.Point(169, 157)
        Me.cmdSlash1.Name = "cmdSlash1"
        Me.cmdSlash1.Size = New System.Drawing.Size(30, 30)
        Me.cmdSlash1.TabIndex = 16
        Me.cmdSlash1.Text = "/"
        Me.cmdSlash1.UseVisualStyleBackColor = True
        '
        'cmdPercent
        '
        Me.cmdPercent.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPercent.Location = New System.Drawing.Point(205, 196)
        Me.cmdPercent.Name = "cmdPercent"
        Me.cmdPercent.Size = New System.Drawing.Size(30, 30)
        Me.cmdPercent.TabIndex = 17
        Me.cmdPercent.Text = "%"
        Me.cmdPercent.UseVisualStyleBackColor = True
        '
        'cmdSlash2
        '
        Me.cmdSlash2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSlash2.Location = New System.Drawing.Point(169, 194)
        Me.cmdSlash2.Name = "cmdSlash2"
        Me.cmdSlash2.Size = New System.Drawing.Size(30, 30)
        Me.cmdSlash2.TabIndex = 18
        Me.cmdSlash2.Text = "\"
        Me.cmdSlash2.UseVisualStyleBackColor = True
        '
        'cmdRoot
        '
        Me.cmdRoot.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.25!)
        Me.cmdRoot.Image = CType(resources.GetObject("cmdRoot.Image"), System.Drawing.Image)
        Me.cmdRoot.Location = New System.Drawing.Point(133, 194)
        Me.cmdRoot.Name = "cmdRoot"
        Me.cmdRoot.Size = New System.Drawing.Size(30, 30)
        Me.cmdRoot.TabIndex = 19
        Me.cmdRoot.UseVisualStyleBackColor = True
        '
        'cmdPlus
        '
        Me.cmdPlus.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPlus.Location = New System.Drawing.Point(277, 160)
        Me.cmdPlus.Name = "cmdPlus"
        Me.cmdPlus.Size = New System.Drawing.Size(30, 97)
        Me.cmdPlus.TabIndex = 20
        Me.cmdPlus.Text = "+"
        Me.cmdPlus.UseVisualStyleBackColor = True
        '
        'cmdReset
        '
        Me.cmdReset.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdReset.Location = New System.Drawing.Point(133, 231)
        Me.cmdReset.Name = "cmdReset"
        Me.cmdReset.Size = New System.Drawing.Size(138, 25)
        Me.cmdReset.TabIndex = 21
        Me.cmdReset.Text = "Reset"
        Me.cmdReset.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.cmdReset.UseVisualStyleBackColor = True
        '
        'cmdMulti
        '
        Me.cmdMulti.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.25!)
        Me.cmdMulti.Location = New System.Drawing.Point(205, 159)
        Me.cmdMulti.Name = "cmdMulti"
        Me.cmdMulti.Size = New System.Drawing.Size(30, 30)
        Me.cmdMulti.TabIndex = 22
        Me.cmdMulti.Text = "*"
        Me.cmdMulti.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.cmdMulti.UseVisualStyleBackColor = True
        '
        'cmdPlusSub
        '
        Me.cmdPlusSub.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPlusSub.Location = New System.Drawing.Point(241, 197)
        Me.cmdPlusSub.Name = "cmdPlusSub"
        Me.cmdPlusSub.Size = New System.Drawing.Size(30, 30)
        Me.cmdPlusSub.TabIndex = 23
        Me.cmdPlusSub.Text = "+ -"
        Me.cmdPlusSub.UseVisualStyleBackColor = True
        '
        'cmdSub
        '
        Me.cmdSub.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSub.Location = New System.Drawing.Point(241, 157)
        Me.cmdSub.Name = "cmdSub"
        Me.cmdSub.Size = New System.Drawing.Size(30, 30)
        Me.cmdSub.TabIndex = 24
        Me.cmdSub.Text = "-"
        Me.cmdSub.UseVisualStyleBackColor = True
        '
        'panel1
        '
        Me.panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.panel1.Controls.Add(Me.Label2)
        Me.panel1.Location = New System.Drawing.Point(22, 157)
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(105, 99)
        Me.panel1.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(43, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(19, 20)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "0"
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(19, 103)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(307, 41)
        Me.Label1.TabIndex = 25
        Me.Label1.Text = "Trage zwei Zahlen in die Textfelder ein und wähle eine Rechenoperation aus!"
        '
        'MyCalc
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(378, 283)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.panel1)
        Me.Controls.Add(Me.cmdSub)
        Me.Controls.Add(Me.cmdPlusSub)
        Me.Controls.Add(Me.cmdMulti)
        Me.Controls.Add(Me.cmdReset)
        Me.Controls.Add(Me.cmdPlus)
        Me.Controls.Add(Me.cmdRoot)
        Me.Controls.Add(Me.cmdSlash2)
        Me.Controls.Add(Me.cmdPercent)
        Me.Controls.Add(Me.cmdSlash1)
        Me.Controls.Add(Me.cmdSquared)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.txt2)
        Me.Controls.Add(Me.txt1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "MyCalc"
        Me.Text = "MyCalc"
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.panel1.ResumeLayout(False)
        Me.panel1.PerformLayout()
        CType(Me.BindingSource1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txt1 As TextBox
    Friend WithEvents BindingSource1 As BindingSource
    Friend WithEvents txt2 As TextBox
    Friend WithEvents PictureBox3 As PictureBox
    Friend WithEvents cmdSquared As Button
    Friend WithEvents cmdSlash1 As Button
    Friend WithEvents cmdPercent As Button
    Friend WithEvents cmdSlash2 As Button
    Friend WithEvents cmdRoot As Button
    Friend WithEvents cmdPlus As Button
    Friend WithEvents cmdReset As Button
    Friend WithEvents cmdMulti As Button
    Friend WithEvents cmdPlusSub As Button
    Friend WithEvents cmdSub As Button
    Friend WithEvents panel1 As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
End Class
