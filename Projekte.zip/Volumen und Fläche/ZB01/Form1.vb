﻿Public Class Form1
    'Variablen deklarieren
    Private dblInput1 As Double = 0
    Private dblInput2 As Double = 0
    Private dblInput3 As Double = 0
    Private dblResult As Double = 0
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Die Form laden
        Me.optArea.Checked = True
        Me.prmtC.Enabled = False
        Me.lblResultArea.Visible = True
        Me.lblResultVolume.Visible = False

    End Sub

    Private Sub btnCalculate_Click(sender As Object, e As EventArgs) Handles btnCalculate.Click

        'Fehlermeldung bei Buchstabeneingabe
        If IsNumeric(prmtA.Text & prmtB.Text & prmtC.Text) = False Then
            MessageBox.Show("Bitte nur Zahlen eintragen!")
            prmtA.Focus()
            Exit Sub
        End If



        'Die eingabe Variablen mit den Zahlen füllen
        dblInput1 = Me.prmtA.Text
        dblInput2 = Me.prmtB.Text

        'Rechnung von Volumen und Fläche/Das unterscheiden dieser
        If Me.prmtC.Enabled = False Then
            dblResult = dblInput1 * dblInput2
        Else
            dblInput3 = Me.prmtC.Text
            dblResult = dblInput1 * dblInput2 * dblInput3
        End If

        Me.pnlRectangle.Width = dblInput2
        Me.pnlRectangle.Height = dblInput1

        'Ausgabefeld mit Ausgabevariable füllen
        Me.txtResult.Text = dblResult

    End Sub

    Private Sub optVolume_CLick(sender As Object, e As EventArgs) Handles optVolume.Click

        'Laden der Form bei Auswahl der "Volumen" option.
        Me.pnlRectangle.Visible = False
        Me.prmtC.Enabled = True
        Me.lblResultArea.Visible = False
        Me.lblResultVolume.Visible = True

    End Sub

    Private Sub optArea_Click(sender As Object, e As EventArgs) Handles optArea.CheckedChanged

        'Laden der Form bei Auswahl der "Flächen" Option.
        Me.pnlRectangle.Visible = True
        Me.prmtC.Enabled = False
        Me.lblResultArea.Visible = True
        Me.lblResultVolume.Visible = False

    End Sub

    Private Sub btnReset_Click(sender As Object, e As EventArgs) Handles btnReset.Click

        'Zurücksetzten der Form
        Me.optArea.Checked = True
        Me.prmtC.Enabled = False
        Me.lblResultArea.Visible = True
        Me.lblResultVolume.Visible = False

        Me.prmtA.Text = ""
        Me.prmtB.Text = ""
        Me.prmtC.Text = ""

    End Sub

    Private Sub btnEnd_Click(sender As Object, e As EventArgs) Handles btnEnd.Click

        'Anwendung beenden  
        Me.Close()


    End Sub


End Class
