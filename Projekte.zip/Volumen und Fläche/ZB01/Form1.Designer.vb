﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnEnd = New System.Windows.Forms.Button()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.optArea = New System.Windows.Forms.RadioButton()
        Me.optVolume = New System.Windows.Forms.RadioButton()
        Me.lblResultVolume = New System.Windows.Forms.Label()
        Me.lblResultArea = New System.Windows.Forms.Label()
        Me.lblC = New System.Windows.Forms.Label()
        Me.lblB = New System.Windows.Forms.Label()
        Me.lblA = New System.Windows.Forms.Label()
        Me.lblEqual = New System.Windows.Forms.Label()
        Me.lblTimes2 = New System.Windows.Forms.Label()
        Me.lblTimes1 = New System.Windows.Forms.Label()
        Me.txtResult = New System.Windows.Forms.TextBox()
        Me.prmtC = New System.Windows.Forms.TextBox()
        Me.prmtB = New System.Windows.Forms.TextBox()
        Me.prmtA = New System.Windows.Forms.TextBox()
        Me.pnlRectangle = New System.Windows.Forms.Panel()
        Me.SuspendLayout()
        '
        'btnReset
        '
        Me.btnReset.Image = CType(resources.GetObject("btnReset.Image"), System.Drawing.Image)
        Me.btnReset.Location = New System.Drawing.Point(544, 151)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(100, 23)
        Me.btnReset.TabIndex = 35
        Me.btnReset.Text = "Reset"
        Me.btnReset.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnEnd
        '
        Me.btnEnd.Image = CType(resources.GetObject("btnEnd.Image"), System.Drawing.Image)
        Me.btnEnd.Location = New System.Drawing.Point(544, 180)
        Me.btnEnd.Name = "btnEnd"
        Me.btnEnd.Size = New System.Drawing.Size(100, 23)
        Me.btnEnd.TabIndex = 34
        Me.btnEnd.Text = "Ende"
        Me.btnEnd.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnEnd.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Image = CType(resources.GetObject("btnCalculate.Image"), System.Drawing.Image)
        Me.btnCalculate.Location = New System.Drawing.Point(544, 122)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(100, 23)
        Me.btnCalculate.TabIndex = 33
        Me.btnCalculate.Text = "Berechnen"
        Me.btnCalculate.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'optArea
        '
        Me.optArea.AutoSize = True
        Me.optArea.Location = New System.Drawing.Point(236, 128)
        Me.optArea.Name = "optArea"
        Me.optArea.Size = New System.Drawing.Size(57, 17)
        Me.optArea.TabIndex = 32
        Me.optArea.TabStop = True
        Me.optArea.Text = "Fläche"
        Me.optArea.UseVisualStyleBackColor = True
        '
        'optVolume
        '
        Me.optVolume.AutoSize = True
        Me.optVolume.Location = New System.Drawing.Point(386, 128)
        Me.optVolume.Name = "optVolume"
        Me.optVolume.Size = New System.Drawing.Size(66, 17)
        Me.optVolume.TabIndex = 31
        Me.optVolume.TabStop = True
        Me.optVolume.Text = "Volumen"
        Me.optVolume.UseVisualStyleBackColor = True
        '
        'lblResultVolume
        '
        Me.lblResultVolume.AutoSize = True
        Me.lblResultVolume.Location = New System.Drawing.Point(541, 63)
        Me.lblResultVolume.Name = "lblResultVolume"
        Me.lblResultVolume.Size = New System.Drawing.Size(18, 13)
        Me.lblResultVolume.TabIndex = 30
        Me.lblResultVolume.Text = "m³"
        '
        'lblResultArea
        '
        Me.lblResultArea.AutoSize = True
        Me.lblResultArea.Location = New System.Drawing.Point(541, 63)
        Me.lblResultArea.Name = "lblResultArea"
        Me.lblResultArea.Size = New System.Drawing.Size(18, 13)
        Me.lblResultArea.TabIndex = 29
        Me.lblResultArea.Text = "m²"
        '
        'lblC
        '
        Me.lblC.AutoSize = True
        Me.lblC.Location = New System.Drawing.Point(383, 63)
        Me.lblC.Name = "lblC"
        Me.lblC.Size = New System.Drawing.Size(14, 13)
        Me.lblC.TabIndex = 28
        Me.lblC.Text = "C"
        '
        'lblB
        '
        Me.lblB.AutoSize = True
        Me.lblB.Location = New System.Drawing.Point(233, 63)
        Me.lblB.Name = "lblB"
        Me.lblB.Size = New System.Drawing.Size(14, 13)
        Me.lblB.TabIndex = 27
        Me.lblB.Text = "B"
        '
        'lblA
        '
        Me.lblA.AutoSize = True
        Me.lblA.Location = New System.Drawing.Point(77, 63)
        Me.lblA.Name = "lblA"
        Me.lblA.Size = New System.Drawing.Size(14, 13)
        Me.lblA.TabIndex = 26
        Me.lblA.Text = "A"
        '
        'lblEqual
        '
        Me.lblEqual.AutoSize = True
        Me.lblEqual.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEqual.Location = New System.Drawing.Point(507, 81)
        Me.lblEqual.Name = "lblEqual"
        Me.lblEqual.Size = New System.Drawing.Size(19, 20)
        Me.lblEqual.TabIndex = 25
        Me.lblEqual.Text = "="
        '
        'lblTimes2
        '
        Me.lblTimes2.AutoSize = True
        Me.lblTimes2.Location = New System.Drawing.Point(353, 86)
        Me.lblTimes2.Name = "lblTimes2"
        Me.lblTimes2.Size = New System.Drawing.Size(14, 13)
        Me.lblTimes2.TabIndex = 24
        Me.lblTimes2.Text = "X"
        '
        'lblTimes1
        '
        Me.lblTimes1.AutoSize = True
        Me.lblTimes1.Location = New System.Drawing.Point(198, 86)
        Me.lblTimes1.Name = "lblTimes1"
        Me.lblTimes1.Size = New System.Drawing.Size(14, 13)
        Me.lblTimes1.TabIndex = 23
        Me.lblTimes1.Text = "X"
        '
        'txtResult
        '
        Me.txtResult.Location = New System.Drawing.Point(544, 79)
        Me.txtResult.Name = "txtResult"
        Me.txtResult.Size = New System.Drawing.Size(100, 20)
        Me.txtResult.TabIndex = 22
        '
        'prmtC
        '
        Me.prmtC.Location = New System.Drawing.Point(386, 79)
        Me.prmtC.Name = "prmtC"
        Me.prmtC.Size = New System.Drawing.Size(100, 20)
        Me.prmtC.TabIndex = 21
        '
        'prmtB
        '
        Me.prmtB.Location = New System.Drawing.Point(236, 79)
        Me.prmtB.Name = "prmtB"
        Me.prmtB.Size = New System.Drawing.Size(100, 20)
        Me.prmtB.TabIndex = 20
        '
        'prmtA
        '
        Me.prmtA.Location = New System.Drawing.Point(80, 79)
        Me.prmtA.Name = "prmtA"
        Me.prmtA.Size = New System.Drawing.Size(100, 20)
        Me.prmtA.TabIndex = 19
        '
        'pnlRectangle
        '
        Me.pnlRectangle.BackColor = System.Drawing.SystemColors.Info
        Me.pnlRectangle.Location = New System.Drawing.Point(64, 244)
        Me.pnlRectangle.Name = "pnlRectangle"
        Me.pnlRectangle.Size = New System.Drawing.Size(200, 100)
        Me.pnlRectangle.TabIndex = 36
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(685, 529)
        Me.Controls.Add(Me.pnlRectangle)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnEnd)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.optArea)
        Me.Controls.Add(Me.optVolume)
        Me.Controls.Add(Me.lblResultVolume)
        Me.Controls.Add(Me.lblResultArea)
        Me.Controls.Add(Me.lblC)
        Me.Controls.Add(Me.lblB)
        Me.Controls.Add(Me.lblA)
        Me.Controls.Add(Me.lblEqual)
        Me.Controls.Add(Me.lblTimes2)
        Me.Controls.Add(Me.lblTimes1)
        Me.Controls.Add(Me.txtResult)
        Me.Controls.Add(Me.prmtC)
        Me.Controls.Add(Me.prmtB)
        Me.Controls.Add(Me.prmtA)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Flächen Berechnen"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnReset As Button
    Friend WithEvents btnEnd As Button
    Friend WithEvents btnCalculate As Button
    Friend WithEvents optArea As RadioButton
    Friend WithEvents optVolume As RadioButton
    Friend WithEvents lblResultVolume As Label
    Friend WithEvents lblResultArea As Label
    Friend WithEvents lblC As Label
    Friend WithEvents lblB As Label
    Friend WithEvents lblA As Label
    Friend WithEvents lblEqual As Label
    Friend WithEvents lblTimes2 As Label
    Friend WithEvents lblTimes1 As Label
    Friend WithEvents txtResult As TextBox
    Friend WithEvents prmtC As TextBox
    Friend WithEvents prmtB As TextBox
    Friend WithEvents prmtA As TextBox
    Friend WithEvents pnlRectangle As Panel
End Class
