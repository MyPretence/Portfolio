﻿Public Class frmInfo

    Private Sub cmdClose_Click(sender As Object, e As EventArgs) Handles cmdClose.Click
        ' Formular schließen
        Me.Close()
    End Sub
    Private Sub frmInfo_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Stringvariable deklarieren
        Dim strInfo As String
        'Infotext an Variable übergeben
        strInfo = "Pferdestärke (Horsepower)" & Chr(13) & Chr(13) &
        "Kurzzeichen PS" & Chr(13) &
        "bis zum 31. 12. 1977 Einheit für die Leistung: 1 PS = " &
        "75 mkp/s. " &
        "Die Leistungseinheit PS ist amtlich durch die Einheit " &
        "Watt ersetzt worden. Es gilt: 1 PS = 735,498 Watt."
        'Infotextvariable über Bezeichnungsfeld ausgeben
        Me.lblInfo.Text = strInfo
        'Formularbeschriftung
        Me.Text = "Info"
    End Sub


End Class