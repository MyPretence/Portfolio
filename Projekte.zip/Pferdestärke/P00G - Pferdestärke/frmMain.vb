﻿Public Class frmMain
    ' Umrechnungsfaktor KW : PS als Konstante deklarieren
    Const dblFaktor As Double = 1.36

    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click
        ' Programm beenden
        Me.Close()
    End Sub

    Private Sub cmdInfo_Click(sender As Object, e As EventArgs) Handles cmdInfo.Click
        ' Info als gebundenes Formular über Funktion
        ' ShowDialog aufrufen
        frmInfo.ShowDialog()
    End Sub
    Private Sub cmdLeistung_Click(sender As Object, e As EventArgs) Handles cmdLeistung.Click

        If optKW.Checked Then

            ' Variablen deklarieren
            Dim dblLeistung As Double, dblKW As Double
            ' Wert aus Textfeld an variable dblLeistung übergeben
            dblLeistung = Me.txtEingabe.Text
            ' KW berechnen
            dblKW = dblLeistung / dblFaktor
            ' Variable dblKW über Bezeichnungsfeld ausgeben
            Me.lblAusgabe.Text = "Ergebnis: " & dblKW & " KW"

        Else

            ' Variablen deklarieren
            Dim dblLeistung As Double, dblPS As Double
            ' Wert aus Textfeld an variable dblLeistung übergeben
            dblLeistung = Me.txtEingabe.Text
            ' PS berechnen
            dblPS = dblLeistung * dblFaktor
            ' Variable dblKW über Bezeichnungsfeld ausgeben
            Me.lblAusgabe.Text = "Ergebnis: " & dblPS & " PS"

        End If

    End Sub
    Private Sub frmMain_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Benutzeroberfläche einrichten
        ' Optionsfelder einrichten
        Me.optKW.Checked = False
        Me.optPS.Checked = True
        'Schaltflächen einrichten
        Me.optPS.Visible = True
        Me.optKW.Visible = True
    End Sub

End Class
