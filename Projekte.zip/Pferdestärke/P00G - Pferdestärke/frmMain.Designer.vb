﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMain))
        Me.lblHinweis = New System.Windows.Forms.Label()
        Me.txtEingabe = New System.Windows.Forms.MaskedTextBox()
        Me.cmdLeistung = New System.Windows.Forms.Button()
        Me.lblAusgabe = New System.Windows.Forms.Label()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.optPS = New System.Windows.Forms.RadioButton()
        Me.optKW = New System.Windows.Forms.RadioButton()
        Me.cmdInfo = New System.Windows.Forms.Button()
        Me.picPferde = New System.Windows.Forms.PictureBox()
        CType(Me.picPferde, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblHinweis
        '
        Me.lblHinweis.AutoSize = True
        Me.lblHinweis.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblHinweis.Location = New System.Drawing.Point(25, 9)
        Me.lblHinweis.Name = "lblHinweis"
        Me.lblHinweis.Size = New System.Drawing.Size(338, 20)
        Me.lblHinweis.TabIndex = 0
        Me.lblHinweis.Text = " Bitte den Leistungswert ins Textfeld eingeben." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'txtEingabe
        '
        Me.txtEingabe.Location = New System.Drawing.Point(28, 34)
        Me.txtEingabe.Name = "txtEingabe"
        Me.txtEingabe.Size = New System.Drawing.Size(112, 20)
        Me.txtEingabe.TabIndex = 1
        '
        'cmdLeistung
        '
        Me.cmdLeistung.Location = New System.Drawing.Point(28, 60)
        Me.cmdLeistung.Name = "cmdLeistung"
        Me.cmdLeistung.Size = New System.Drawing.Size(112, 23)
        Me.cmdLeistung.TabIndex = 2
        Me.cmdLeistung.Text = "Leistung Berechnen"
        Me.cmdLeistung.UseVisualStyleBackColor = True
        '
        'lblAusgabe
        '
        Me.lblAusgabe.AutoSize = True
        Me.lblAusgabe.Location = New System.Drawing.Point(25, 106)
        Me.lblAusgabe.Name = "lblAusgabe"
        Me.lblAusgabe.Size = New System.Drawing.Size(0, 13)
        Me.lblAusgabe.TabIndex = 3
        '
        'cmdExit
        '
        Me.cmdExit.Location = New System.Drawing.Point(28, 160)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.Size = New System.Drawing.Size(75, 23)
        Me.cmdExit.TabIndex = 4
        Me.cmdExit.Text = "Ende"
        Me.cmdExit.UseVisualStyleBackColor = True
        '
        'optPS
        '
        Me.optPS.AutoSize = True
        Me.optPS.Location = New System.Drawing.Point(226, 58)
        Me.optPS.Name = "optPS"
        Me.optPS.Size = New System.Drawing.Size(93, 17)
        Me.optPS.TabIndex = 5
        Me.optPS.TabStop = True
        Me.optPS.Text = "Leistung in PS"
        Me.optPS.UseVisualStyleBackColor = True
        '
        'optKW
        '
        Me.optKW.AutoSize = True
        Me.optKW.Location = New System.Drawing.Point(226, 35)
        Me.optKW.Name = "optKW"
        Me.optKW.Size = New System.Drawing.Size(97, 17)
        Me.optKW.TabIndex = 6
        Me.optKW.TabStop = True
        Me.optKW.Text = "Leistung in KW"
        Me.optKW.UseVisualStyleBackColor = True
        '
        'cmdInfo
        '
        Me.cmdInfo.Image = CType(resources.GetObject("cmdInfo.Image"), System.Drawing.Image)
        Me.cmdInfo.Location = New System.Drawing.Point(361, 34)
        Me.cmdInfo.Name = "cmdInfo"
        Me.cmdInfo.Size = New System.Drawing.Size(56, 49)
        Me.cmdInfo.TabIndex = 7
        Me.cmdInfo.UseVisualStyleBackColor = True
        '
        'picPferde
        '
        Me.picPferde.Image = CType(resources.GetObject("picPferde.Image"), System.Drawing.Image)
        Me.picPferde.Location = New System.Drawing.Point(245, 106)
        Me.picPferde.Name = "picPferde"
        Me.picPferde.Size = New System.Drawing.Size(232, 324)
        Me.picPferde.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.picPferde.TabIndex = 8
        Me.picPferde.TabStop = False
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(488, 205)
        Me.Controls.Add(Me.picPferde)
        Me.Controls.Add(Me.cmdInfo)
        Me.Controls.Add(Me.optKW)
        Me.Controls.Add(Me.optPS)
        Me.Controls.Add(Me.cmdExit)
        Me.Controls.Add(Me.lblAusgabe)
        Me.Controls.Add(Me.cmdLeistung)
        Me.Controls.Add(Me.txtEingabe)
        Me.Controls.Add(Me.lblHinweis)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frmMain"
        Me.Text = "Pferdestärke"
        CType(Me.picPferde, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblHinweis As Label
    Friend WithEvents txtEingabe As MaskedTextBox
    Friend WithEvents cmdLeistung As Button
    Friend WithEvents lblAusgabe As Label
    Friend WithEvents cmdExit As Button
    Friend WithEvents optPS As RadioButton
    Friend WithEvents optKW As RadioButton
    Friend WithEvents cmdInfo As Button
    Friend WithEvents picPferde As PictureBox
End Class
