﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmZahlenRaten
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lbl1 = New System.Windows.Forms.Label()
        Me.txtEingabe = New System.Windows.Forms.TextBox()
        Me.cmdBeenden = New System.Windows.Forms.Button()
        Me.cmdSpielen = New System.Windows.Forms.Button()
        Me.cmdRichtigeZahl = New System.Windows.Forms.Button()
        Me.lblKleineZahl = New System.Windows.Forms.Label()
        Me.lblGrosseZahl = New System.Windows.Forms.Label()
        Me.lblRichtigeZahl = New System.Windows.Forms.Label()
        Me.lblAnzahlVersuche = New System.Windows.Forms.Label()
        Me.lblInfo = New System.Windows.Forms.Label()
        Me.lbl2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'lbl1
        '
        Me.lbl1.AutoSize = True
        Me.lbl1.Location = New System.Drawing.Point(306, 92)
        Me.lbl1.Name = "lbl1"
        Me.lbl1.Size = New System.Drawing.Size(55, 13)
        Me.lbl1.TabIndex = 4
        Me.lbl1.Text = "Versuche:"
        '
        'txtEingabe
        '
        Me.txtEingabe.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEingabe.Location = New System.Drawing.Point(182, 53)
        Me.txtEingabe.Name = "txtEingabe"
        Me.txtEingabe.Size = New System.Drawing.Size(118, 26)
        Me.txtEingabe.TabIndex = 7
        '
        'cmdBeenden
        '
        Me.cmdBeenden.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBeenden.ForeColor = System.Drawing.Color.Firebrick
        Me.cmdBeenden.Location = New System.Drawing.Point(306, 199)
        Me.cmdBeenden.Name = "cmdBeenden"
        Me.cmdBeenden.Size = New System.Drawing.Size(118, 43)
        Me.cmdBeenden.TabIndex = 10
        Me.cmdBeenden.Text = "Beenden"
        Me.cmdBeenden.UseVisualStyleBackColor = True
        '
        'cmdSpielen
        '
        Me.cmdSpielen.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSpielen.ForeColor = System.Drawing.Color.ForestGreen
        Me.cmdSpielen.Location = New System.Drawing.Point(182, 199)
        Me.cmdSpielen.Name = "cmdSpielen"
        Me.cmdSpielen.Size = New System.Drawing.Size(118, 43)
        Me.cmdSpielen.TabIndex = 11
        Me.cmdSpielen.Text = "Spielen"
        Me.cmdSpielen.UseVisualStyleBackColor = True
        '
        'cmdRichtigeZahl
        '
        Me.cmdRichtigeZahl.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdRichtigeZahl.ForeColor = System.Drawing.Color.ForestGreen
        Me.cmdRichtigeZahl.Location = New System.Drawing.Point(182, 92)
        Me.cmdRichtigeZahl.Name = "cmdRichtigeZahl"
        Me.cmdRichtigeZahl.Size = New System.Drawing.Size(118, 43)
        Me.cmdRichtigeZahl.TabIndex = 12
        Me.cmdRichtigeZahl.Text = "Richtige Zahl?"
        Me.cmdRichtigeZahl.UseVisualStyleBackColor = True
        '
        'lblKleineZahl
        '
        Me.lblKleineZahl.AutoSize = True
        Me.lblKleineZahl.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblKleineZahl.ForeColor = System.Drawing.Color.Red
        Me.lblKleineZahl.Location = New System.Drawing.Point(12, 53)
        Me.lblKleineZahl.Name = "lblKleineZahl"
        Me.lblKleineZahl.Size = New System.Drawing.Size(40, 42)
        Me.lblKleineZahl.TabIndex = 14
        Me.lblKleineZahl.Text = "0"
        '
        'lblGrosseZahl
        '
        Me.lblGrosseZahl.AutoSize = True
        Me.lblGrosseZahl.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblGrosseZahl.ForeColor = System.Drawing.Color.Red
        Me.lblGrosseZahl.Location = New System.Drawing.Point(12, 137)
        Me.lblGrosseZahl.Name = "lblGrosseZahl"
        Me.lblGrosseZahl.Size = New System.Drawing.Size(40, 42)
        Me.lblGrosseZahl.TabIndex = 15
        Me.lblGrosseZahl.Text = "0"
        '
        'lblRichtigeZahl
        '
        Me.lblRichtigeZahl.AutoSize = True
        Me.lblRichtigeZahl.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblRichtigeZahl.ForeColor = System.Drawing.Color.ForestGreen
        Me.lblRichtigeZahl.Location = New System.Drawing.Point(12, 95)
        Me.lblRichtigeZahl.Name = "lblRichtigeZahl"
        Me.lblRichtigeZahl.Size = New System.Drawing.Size(40, 42)
        Me.lblRichtigeZahl.TabIndex = 16
        Me.lblRichtigeZahl.Text = "0"
        '
        'lblAnzahlVersuche
        '
        Me.lblAnzahlVersuche.AutoSize = True
        Me.lblAnzahlVersuche.Font = New System.Drawing.Font("Microsoft Sans Serif", 27.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAnzahlVersuche.ForeColor = System.Drawing.Color.ForestGreen
        Me.lblAnzahlVersuche.Location = New System.Drawing.Point(367, 68)
        Me.lblAnzahlVersuche.Name = "lblAnzahlVersuche"
        Me.lblAnzahlVersuche.Size = New System.Drawing.Size(40, 42)
        Me.lblAnzahlVersuche.TabIndex = 17
        Me.lblAnzahlVersuche.Text = "0"
        '
        'lblInfo
        '
        Me.lblInfo.AutoSize = True
        Me.lblInfo.Location = New System.Drawing.Point(154, 183)
        Me.lblInfo.Name = "lblInfo"
        Me.lblInfo.Size = New System.Drawing.Size(182, 13)
        Me.lblInfo.TabIndex = 18
        Me.lblInfo.Text = "Klicke auf >Spielen< um zu beginnen"
        '
        'lbl2
        '
        Me.lbl2.AutoSize = True
        Me.lbl2.Location = New System.Drawing.Point(98, 61)
        Me.lbl2.Name = "lbl2"
        Me.lbl2.Size = New System.Drawing.Size(78, 13)
        Me.lbl2.TabIndex = 19
        Me.lbl2.Text = "Zahl eingeben:"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(450, 254)
        Me.Controls.Add(Me.lbl2)
        Me.Controls.Add(Me.lblInfo)
        Me.Controls.Add(Me.lblAnzahlVersuche)
        Me.Controls.Add(Me.lblRichtigeZahl)
        Me.Controls.Add(Me.lblGrosseZahl)
        Me.Controls.Add(Me.lblKleineZahl)
        Me.Controls.Add(Me.cmdRichtigeZahl)
        Me.Controls.Add(Me.cmdSpielen)
        Me.Controls.Add(Me.cmdBeenden)
        Me.Controls.Add(Me.txtEingabe)
        Me.Controls.Add(Me.lbl1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbl1 As Label
    Friend WithEvents txtEingabe As TextBox
    Friend WithEvents cmdBeenden As Button
    Friend WithEvents cmdSpielen As Button
    Friend WithEvents cmdRichtigeZahl As Button
    Friend WithEvents lblKleineZahl As Label
    Friend WithEvents lblGrosseZahl As Label
    Friend WithEvents lblRichtigeZahl As Label
    Friend WithEvents lblAnzahlVersuche As Label
    Friend WithEvents lblInfo As Label
    Friend WithEvents lbl2 As Label
End Class
