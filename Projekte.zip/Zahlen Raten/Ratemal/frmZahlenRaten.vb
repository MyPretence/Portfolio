﻿Public Class frmZahlenRaten
    Dim intZufallsZahl As Integer = 500     'Zufallszahl
    Dim intVersuche As Integer = 0          'versuche des Spieleres

    Private Sub cmdSpielen_Click(sender As Object, e As EventArgs) Handles cmdSpielen.Click
        lblInfo.Text = "Gib eine Zahl zwischen 1 und 1000 ein," & vbCrLf &
            "klicke danach auf >Richtige Zahl"
        cmdRichtigeZahl.Enabled = True
        cmdSpielen.Enabled = False

        Dim intRandom As New Random
        intZufallsZahl = intRandom.Next(1, 1000)
        lblKleineZahl.Text = 1 : lblGrosseZahl.Text = "?"
        intVersuche = 0
        lblAnzahlVersuche.Text = intVersuche.ToString
        AktiviereTextfeld()
    End Sub

    Sub AktiviereTextfeld()
        txtEingabe.Enabled = True : txtEingabe.Clear() : txtEingabe.Focus()
    End Sub

    Private Sub cmdBeenden_Click(sender As Object, e As EventArgs) Handles cmdBeenden.Click
        Close()
    End Sub

    Private Sub cmdRichtigeZahl_Click(sender As Object, e As EventArgs) Handles cmdRichtigeZahl.Click
        ProbeEingabe()
    End Sub

    Sub ProbeEingabe()
        'ausvertung der Nutzereingabe
        Dim intNutzerZahl As Integer
        Dim strNeueEingabe = "Versuch es noch einmal."
        Try
            intNutzerZahl = Convert.ToInt32(txtEingabe.Text) 'text in Int umwandeln
        Catch ex As Exception
            lblInfo.Text = "Fehler: Du musst eine Zahl eingeben."
            AktiviereTextfeld()
            Exit Sub
        End Try
        intVersuche += 1 'Hochzählen der versuche
        lblAnzahlVersuche.Text = intVersuche.ToString

        If intNutzerZahl Then
            lblInfo.Text = txtEingabe.Text & " ist die gesuchte Zahl!" & vbCrLf &
                "Du hast " & intVersuche.ToString & " Versuche benötigt!"
            lblRichtigeZahl.Text = txtEingabe.Text
            EventuellNeuesSpiel()
        ElseIf intNutzerZahl < intZufallsZahl Then
            lblKleineZahl.Text = txtEingabe.Text
            lblInfo.Text = "Die Zahl " & txtEingabe.Text & " ist zu groß!" & vbCrLf & strNeueEingabe
            AktiviereTextfeld()
        Else
            lblGrosseZahl.Text = txtEingabe.Text
            lblInfo.Text = "Die Zahl " & txtEingabe.Text & " ist zu Groß!" & vbCrLf & strNeueEingabe
            AktiviereTextfeld()
        End If
    End Sub

    Sub EventuellNeuesSpiel()
        cmdSpielen.Text = "Neues Spiel" : cmdSpielen.Enabled = True : cmdSpielen.Focus()
        txtEingabe.Clear() : txtEingabe.Enabled = False
        cmdRichtigeZahl.Enabled = False
        intVersuche = 0
    End Sub

End Class
