﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Das Formular überschreibt den Löschvorgang, um die Komponentenliste zu bereinigen.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Wird vom Windows Form-Designer benötigt.
    Private components As System.ComponentModel.IContainer

    'Hinweis: Die folgende Prozedur ist für den Windows Form-Designer erforderlich.
    'Das Bearbeiten ist mit dem Windows Form-Designer möglich.  
    'Das Bearbeiten mit dem Code-Editor ist nicht möglich.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cmdAusgabe = New System.Windows.Forms.Button()
        Me.txtEingabe = New System.Windows.Forms.TextBox()
        Me.PanelAusgabe = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.chkKelvin = New System.Windows.Forms.CheckBox()
        Me.optGradC = New System.Windows.Forms.RadioButton()
        Me.optGradF = New System.Windows.Forms.RadioButton()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblAusgabe = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.PanelAusgabe.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Panel1.Controls.Add(Me.cmdAusgabe)
        Me.Panel1.Controls.Add(Me.txtEingabe)
        Me.Panel1.Controls.Add(Me.PanelAusgabe)
        Me.Panel1.Controls.Add(Me.Panel4)
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.Panel3)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(361, 230)
        Me.Panel1.TabIndex = 0
        '
        'cmdAusgabe
        '
        Me.cmdAusgabe.BackColor = System.Drawing.Color.White
        Me.cmdAusgabe.Location = New System.Drawing.Point(16, 149)
        Me.cmdAusgabe.Name = "cmdAusgabe"
        Me.cmdAusgabe.Size = New System.Drawing.Size(127, 23)
        Me.cmdAusgabe.TabIndex = 6
        Me.cmdAusgabe.Text = "Berechnen"
        Me.cmdAusgabe.UseVisualStyleBackColor = False
        '
        'txtEingabe
        '
        Me.txtEingabe.Location = New System.Drawing.Point(16, 85)
        Me.txtEingabe.Name = "txtEingabe"
        Me.txtEingabe.Size = New System.Drawing.Size(234, 20)
        Me.txtEingabe.TabIndex = 5
        Me.txtEingabe.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'PanelAusgabe
        '
        Me.PanelAusgabe.BackColor = System.Drawing.Color.Black
        Me.PanelAusgabe.Controls.Add(Me.lblAusgabe)
        Me.PanelAusgabe.ForeColor = System.Drawing.Color.White
        Me.PanelAusgabe.Location = New System.Drawing.Point(16, 111)
        Me.PanelAusgabe.Name = "PanelAusgabe"
        Me.PanelAusgabe.Size = New System.Drawing.Size(234, 23)
        Me.PanelAusgabe.TabIndex = 4
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.Color.FromArgb(CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Panel4.Controls.Add(Me.Label1)
        Me.Panel4.Location = New System.Drawing.Point(16, 12)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(331, 24)
        Me.Panel4.TabIndex = 3
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(3, 5)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(207, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Grad Celsius / Grad Fahrenheit berechnen" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.Aquamarine
        Me.Panel2.Controls.Add(Me.chkKelvin)
        Me.Panel2.Controls.Add(Me.optGradC)
        Me.Panel2.Controls.Add(Me.optGradF)
        Me.Panel2.Location = New System.Drawing.Point(256, 85)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(91, 97)
        Me.Panel2.TabIndex = 1
        '
        'chkKelvin
        '
        Me.chkKelvin.AutoSize = True
        Me.chkKelvin.Location = New System.Drawing.Point(24, 55)
        Me.chkKelvin.Name = "chkKelvin"
        Me.chkKelvin.Size = New System.Drawing.Size(55, 17)
        Me.chkKelvin.TabIndex = 1
        Me.chkKelvin.Text = "Kelvin"
        Me.chkKelvin.UseVisualStyleBackColor = True
        '
        'optGradC
        '
        Me.optGradC.AutoSize = True
        Me.optGradC.Location = New System.Drawing.Point(24, 9)
        Me.optGradC.Name = "optGradC"
        Me.optGradC.Size = New System.Drawing.Size(36, 17)
        Me.optGradC.TabIndex = 0
        Me.optGradC.TabStop = True
        Me.optGradC.Text = "*C"
        Me.optGradC.UseVisualStyleBackColor = True
        '
        'optGradF
        '
        Me.optGradF.AutoSize = True
        Me.optGradF.Location = New System.Drawing.Point(24, 32)
        Me.optGradF.Name = "optGradF"
        Me.optGradF.Size = New System.Drawing.Size(35, 17)
        Me.optGradF.TabIndex = 0
        Me.optGradF.TabStop = True
        Me.optGradF.Text = "*F"
        Me.optGradF.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.White
        Me.Panel3.Controls.Add(Me.Label2)
        Me.Panel3.Location = New System.Drawing.Point(16, 12)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(331, 56)
        Me.Panel3.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(3, 27)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(179, 20)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "100 *C = 212 *F = 373 K" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'lblAusgabe
        '
        Me.lblAusgabe.AutoSize = True
        Me.lblAusgabe.BackColor = System.Drawing.Color.Transparent
        Me.lblAusgabe.Location = New System.Drawing.Point(77, 6)
        Me.lblAusgabe.Name = "lblAusgabe"
        Me.lblAusgabe.Size = New System.Drawing.Size(64, 13)
        Me.lblAusgabe.TabIndex = 0
        Me.lblAusgabe.Text = "0 *C = 32 *F"
        Me.lblAusgabe.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(359, 189)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.PanelAusgabe.ResumeLayout(False)
        Me.PanelAusgabe.PerformLayout()
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel3.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents cmdAusgabe As Button
    Friend WithEvents txtEingabe As TextBox
    Friend WithEvents PanelAusgabe As Panel
    Friend WithEvents optGradC As RadioButton
    Friend WithEvents Panel4 As Panel
    Friend WithEvents optGradF As RadioButton
    Friend WithEvents chkKelvin As CheckBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblAusgabe As Label

End Class
