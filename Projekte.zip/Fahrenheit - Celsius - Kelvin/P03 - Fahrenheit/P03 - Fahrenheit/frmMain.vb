﻿Public Class Form1

    'Variablen deklarieren
    Private siGradC As Single = 1.36 ' Celsius
    Private siGradF As Single = 1.36 ' Fahrenheit
    Private siKelvin As Single = 1.36 ' Kelvin
    Private stAusgabe As String 'Ergebnis

    Private Sub cmdAusgabe_Click(sender As Object, e As EventArgs) Handles cmdAusgabe.Click

        If optGradC.Checked = True Then
            siGradC = Me.txtEingabe.Text
            siGradF = siGradC * 1.8 + 32 'Fahrenheit
            siKelvin = (siGradF + 459.67) / 1.8 'Kelvin
            'Ergebnis der Berechnung zu Variable weiterleiten
            stAusgabe = siGradC & " °C = " & siGradF & " °F"
        Else
            'Option Wert in Textbox ist Grad Fahrenheit

            siGradF = Me.txtEingabe.Text
            siGradC = (siGradF - 32) / 1.8 'Celsius
            siKelvin = (siGradF + 459.67) / 1.8 'Kelvin
            ''Ergebnis der Berechnung zu Variable weiterleiten
            stAusgabe = siGradC & " °C = " & siGradF & " °F"
        End If
        'Wenn-Bedingung überprüft Checkbox Kelvin
        If Me.chkKelvin.Checked = False Then
            'Ausgabe ohne Kelvin
            Me.lblAusgabe.Text = stAusgabe
        Else
            'Ausgabe mit Kelvin
            Me.lblAusgabe.Text = stAusgabe & " = " & siKelvin & " K"
        End If

    End Sub

End Class
